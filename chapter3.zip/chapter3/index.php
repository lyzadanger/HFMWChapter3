<!DOCTYPE html>
<html>
<head>
  <title>Creature Comforts Agent Portal: Desktop Version</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
  <h1>Desktop Landing Page</h1>
  <p>If you hit this page, perhaps you are using a browser with a desktop-looking User Agent? Having trouble getting the mobile redirect to work, or otherwise <a href="index_mobile.html">seeking the mobile mockup landing page</a>?</p> 
</body>
</html>